#include<iostream>
using namespace std;
int main(){
    cout<<5+5<<endl;
}