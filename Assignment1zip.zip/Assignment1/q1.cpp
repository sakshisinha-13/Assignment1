#include<iostream>
using namespace std;
int main(){
    cout<<"Physics"<<endl<<"Wallah";
}