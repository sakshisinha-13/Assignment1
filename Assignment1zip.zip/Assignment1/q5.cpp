#include <iostream>
using namespace std;
int main() {
 int r = 10;
 int pi = 3.14;
 int circumference = 2 * pi * r;
 cout << circumference;
}